(function($) {
  $("#text-heading").typeIt({
     strings: ["I'm a Developer", "I'm a Blogger", "Karan Srivastava"],
     speed: 130,
     startDelay: 110,
     breakLines: false,
     autoStart: false
  })
})(jQuery);
